namespace Unity.VisualScripting
{
    public sealed class ValueOutputDefinition : ValuePortDefinition, IUnitOutputPortDefinition { }
}
