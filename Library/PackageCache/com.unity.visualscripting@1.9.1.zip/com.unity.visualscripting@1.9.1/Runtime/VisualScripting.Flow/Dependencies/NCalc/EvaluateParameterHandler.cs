namespace Unity.VisualScripting.Dependencies.NCalc
{
    public delegate void EvaluateParameterHandler(Flow flow, string name, ParameterArgs args);
}
