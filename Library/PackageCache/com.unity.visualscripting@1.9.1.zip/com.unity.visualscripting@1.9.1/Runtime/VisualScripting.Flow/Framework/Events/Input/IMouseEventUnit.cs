namespace Unity.VisualScripting
{
    public interface IMouseEventUnit
    {

    }
}
