namespace Unity.VisualScripting
{
    public interface IObjectVariableUnit : IVariableUnit { }
}
