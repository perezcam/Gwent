namespace Unity.VisualScripting
{
    public interface IVariableUnit : IUnit
    {
        ValueInput name { get; }
    }
}
