namespace Unity.VisualScripting
{
    public enum ScriptGraphContainerType
    {
        GameObject,
        ScriptMachine
    }
}
