namespace Unity.VisualScripting
{
    public static class StateEventHooks
    {
        public const string OnEnterState = nameof(OnEnterState);
        public const string OnExitState = nameof(OnExitState);
    }
}
