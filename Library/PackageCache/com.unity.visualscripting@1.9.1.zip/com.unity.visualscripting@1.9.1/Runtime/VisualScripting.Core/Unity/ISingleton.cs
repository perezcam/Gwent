namespace Unity.VisualScripting
{
    public interface ISingleton { }
}
