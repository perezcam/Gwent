# com.unity.sysroot

This is the base sysroot package, containing common code.  It is intended to be used only as a dependency by sysroot or toolchain packages.
