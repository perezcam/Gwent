using System;

namespace UnityEditor.Timeline
{
    interface IMenuChecked
    {
        bool isChecked { get; }
    }
}
