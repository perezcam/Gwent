namespace UnityEngine.U2D.IK
{
    internal static class IconUtility
    {
        public const string IconPath = "Packages/com.unity.2d.animation/Editor/Assets/ComponentIcons/";
    }
}