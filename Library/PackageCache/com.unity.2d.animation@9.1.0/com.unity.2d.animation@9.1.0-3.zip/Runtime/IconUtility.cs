namespace UnityEngine.U2D.Animation
{
    internal static class IconUtility
    {
        public const string IconPath = "Packages/com.unity.2d.animation/Editor/Assets/ComponentIcons/";
    }
}
