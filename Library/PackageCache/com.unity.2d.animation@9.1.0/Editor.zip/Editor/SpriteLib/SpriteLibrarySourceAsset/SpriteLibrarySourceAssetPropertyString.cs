namespace UnityEditor.U2D.Animation
{
    internal static class SpriteLibrarySourceAssetPropertyString
    {
        public const string library = "m_Library";
        public const string primaryLibraryGUID = "m_PrimaryLibraryGUID";
        public const string modificationHash = "m_ModificationHash";
    }
}
