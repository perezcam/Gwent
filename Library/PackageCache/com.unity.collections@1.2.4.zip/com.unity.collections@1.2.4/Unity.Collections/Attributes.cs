using System;

namespace Unity.Collections
{
#if !UNITY_PROPERTIES_EXISTS
    class CreatePropertyAttribute : Attribute { }
#endif
}
