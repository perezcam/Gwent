# Changelog

## [2.0.0] - 2023-06-04
### Added
- Added the Aseprite Importer to the feature set.

## [1.0.0] - 2021-04-23
### Added
- This is the first release of *2D* feature set.
