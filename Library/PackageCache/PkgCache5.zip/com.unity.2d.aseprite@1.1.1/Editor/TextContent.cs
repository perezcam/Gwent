namespace UnityEditor.U2D.Aseprite
{
    internal static class TextContent
    {
        internal static readonly string noSpriteOrTextureImportWarning = L10n.Tr("No Sprites or Texture are generated. Possibly because all layers in file are hidden or failed to generate texture.");
    }
}