Aseprite Importer

ScriptedImporter to import .ase/.aseprite files into Unity.