# What's new in version 1.1.0

- Added a mosaic padding option to the importer editor.
- Added Generate Physics Shape option to the importer editor.