using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.SpriteShape.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.SpriteShape.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.RenderPipelines.Universal.2D.ShadowProvider.Runtime")]