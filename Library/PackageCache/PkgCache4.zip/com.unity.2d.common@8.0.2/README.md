2D Shared Code

- UTess - a 2D geometry generation toolkit.
- ImagePacker - fits  a list of textures or rects into a bigger rect. 