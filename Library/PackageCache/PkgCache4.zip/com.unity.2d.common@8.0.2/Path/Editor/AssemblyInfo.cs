using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.2D.Common.Path.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.SpriteShape.Editor")]