using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.SpriteShape.Runtime")]
[assembly: InternalsVisibleTo("Unity.2D.Common.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Runtime")]