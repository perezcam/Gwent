using UnityEngine.Animations;

namespace UnityEngine.U2D.Common
{
    internal interface IPreviewable : IAnimationPreviewable { }
}
