using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.PixelPerfect.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.PixelPerfect.Tests.RuntimeTests")]
